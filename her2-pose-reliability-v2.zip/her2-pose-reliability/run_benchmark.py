"""Run the full pipeline on a public benchmark table.

    python -m scripts.make_mock_benchmark            # offline dry run
    python run_benchmark.py --table data/mock_benchmark_raw.csv

    # then, with the real download:
    python run_benchmark.py --table data/benchmark_raw.csv

Prints exactly the numbers the resume needs, and writes them to
artifacts/benchmark/resume_numbers.json.
"""
from __future__ import annotations

import argparse
import json

from src.batch_score import aggregate_candidates, score_batch
from src.evaluate import evaluate
from src.io_utils import write_json
from src.preprocess import preprocess
from src.register import register
from src.train import train

OUT = "artifacts/benchmark"


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--table", required=True, help="downloaded benchmark CSV")
    ap.add_argument("--mapping", default="config/benchmark_mapping.yaml")
    ap.add_argument("--out", default=OUT)
    ap.add_argument("--seed", type=int, default=0)
    args = ap.parse_args()

    print("== 1/5 preprocess ==")
    p = preprocess(output_prefix=args.out, input_uri=args.table,
                   source="benchmark", mapping_path=args.mapping, seed=args.seed)
    print(json.dumps({k: v for k, v in p.items() if not k.endswith("_uri")},
                     indent=2, default=str))

    print("\n== 2/5 train (GroupKFold by structure_id) ==")
    t = train(p["train_uri"], p["cutoffs_uri"], args.out, seed=args.seed)
    print("selected model:", t["selected_model"])
    print("rule baseline CV  false_pass_rate=%.4f macro_f1=%.4f"
          % (t["rule_baseline_cv"]["false_pass_rate"], t["rule_baseline_cv"]["macro_f1"]))
    for name, m in t["model_cv"].items():
        print("  %-20s false_pass_rate=%.4f macro_f1=%.4f pass_cut=%.2f fail_cut=%.2f"
              % (name, m["false_pass_rate"], m["macro_f1"], m["pass_cut"], m["fail_cut"]))

    print("\n== 3/5 evaluate on held-out structures ==")
    e = evaluate(p["test_uri"], t["model_uri"], p["cutoffs_uri"], args.out)
    r = e["evaluation_result"]
    print("model         false_pass_rate=%.4f false_fail_rate=%.4f macro_f1=%.4f brier=%.4f"
          % (r["model"]["false_pass_rate"], r["model"]["false_fail_rate"],
             r["model"]["macro_f1"], r["model"].get("brier", float("nan"))))
    print("rule baseline false_pass_rate=%.4f false_fail_rate=%.4f macro_f1=%.4f"
          % (r["rule_baseline"]["false_pass_rate"], r["rule_baseline"]["false_fail_rate"],
             r["rule_baseline"]["macro_f1"]))

    print("\n== 4/5 conditional register ==")
    reg = register(r, t["model_uri"], args.out)
    print("registered:", reg["registered"], "| approval:", reg["approval_status"])

    print("\n== 5/5 batch score + candidate aggregation ==")
    s = score_batch(p["test_uri"], t["model_uri"], p["cutoffs_uri"], args.out)
    print("rows=%d  batch=%.3fs  %.3f ms/row  cpu=%s"
          % (s["rows_scored"], s["batch_seconds"], s["ms_per_row"], s["cpu_count"]))
    aggregate_candidates(s["scored_uri"], s["blocked_uri"], args.out)

    numbers = {
        "dataset_source": p["provenance"]["source_name"],
        "substitutions_made": p["provenance"].get("substitutions", []),
        "rows_total": p["n_raw_rows"],
        "rows_scorable": p["n_scorable_rows"],
        "rows_blocked": p["n_blocked_rows"],
        "blocked_breakdown": p["blocked_breakdown"],
        "n_classes": 3,
        "classes": ["Pass", "Review", "Fail"],
        "train_rows": p["n_train_rows"],
        "train_structures": p["n_train_structures"],
        "test_rows": p["n_test_rows"],
        "test_structures": p["n_test_structures"],
        "split": "leave-structures-out holdout; GroupKFold by structure_id inside train",
        "models_compared": ["rule_baseline"] + list(t["model_cv"].keys()),
        "selected_model": t["selected_model"],
        "selection_rule": t["selection_rule"],
        "cut_points_locked_on": "out-of-fold predictions",
        "pass_cut": t["locked_pass_cut"],
        "fail_cut": t["locked_fail_cut"],
        "heldout_model_false_pass_rate": r["model"]["false_pass_rate"],
        "heldout_baseline_false_pass_rate": r["rule_baseline"]["false_pass_rate"],
        "heldout_model_macro_f1": r["model"]["macro_f1"],
        "heldout_baseline_macro_f1": r["rule_baseline"]["macro_f1"],
        "delta_false_pass_rate": r["delta_false_pass_rate"],
        "delta_macro_f1": r["delta_macro_f1"],
        "inference_rows": s["rows_scored"],
        "inference_ms_per_row": s["ms_per_row"],
        "inference_cpu_count": s["cpu_count"],
    }
    write_json(numbers, f"{args.out}/resume_numbers.json")

    print("\n" + "=" * 66)
    print("RESUME NUMBERS  ->  %s/resume_numbers.json" % args.out)
    print("=" * 66)
    for k, v in numbers.items():
        print(f"  {k:<38} {v}")


if __name__ == "__main__":
    main()
